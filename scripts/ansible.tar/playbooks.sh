#! /bin/bash

ansible-playbook -v -u ubuntu -i /home/cassandra/ansible-hosts.cfg --private-key /home/ubuntu/.ssh/id_rsa /home/cassandra/os-config.yml --extra-vars "host=local"
ansible-playbook -v -u ubuntu -i /home/cassandra/ansible-hosts.cfg --private-key /home/ubuntu/.ssh/id_rsa /home/cassandra/ebs-init.yml --extra-vars "host=local"
ansible-playbook -v -u ubuntu -i /home/cassandra/ansible-hosts.cfg --private-key /home/ubuntu/.ssh/id_rsa /home/cassandra/dse-directories.yml --extra-vars "host=local"
