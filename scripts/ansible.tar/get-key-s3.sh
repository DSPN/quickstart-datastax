#! /bin/bash

echo "Getting key from $1"

rm -rf /home/ubuntu/.ssh/id_rsa*
aws s3 cp $1/id_rsa /home/ubuntu/.ssh
aws s3 cp $1/id_rsa.pub /home/ubuntu/.ssh

sudo chown ubuntu:ubuntu /home/ubuntu/.ssh/id_rsa*
sudo chmod 400 /home/ubuntu/.ssh/id_rsa

cat /home/ubuntu/.ssh/id_rsa.pub >> /home/ubuntu/.ssh/authorized_keys

export ANSIBLE_HOST_KEY_CHECKING=False
