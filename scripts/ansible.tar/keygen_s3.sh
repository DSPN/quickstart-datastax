#! /bin/bash

rm -rf /home/ubuntu/.ssh/id_rsa*
ssh-keygen -q -N "" -f /home/ubuntu/.ssh/id_rsa
sudo chown ubuntu:ubuntu /home/ubuntu/.ssh/id_rsa*
cat /home/ubuntu/.ssh/id_rsa.pub >> /home/ubuntu/.ssh/authorized_keys

aws s3 cp /home/ubuntu/.ssh/id_rsa $1
aws s3 cp /home/ubuntu/.ssh/id_rsa.pub $1

export ANSIBLE_HOST_KEY_CHECKING=False

