# Description

Sample ansible playbooks used to install, configure, and start DSE

These would need to be modified for cloud specifics and changes for DDAC

ssh key needs to be on all nodes

example for DSE 
nd OPSC
export ANSIBLE_HOST_KEY_CHECKING=False
# seed node
/usr/local/bin/ansible-playbook -u root /home/dse/dse-azure-install/os-config.yml --extra-vars "host=SEED"
/usr/local/bin/ansible-playbook -u root /home/dse/dse-azure-install/ebs-init.yml --extra-vars "host=SEED"
/usr/local/bin/ansible-playbook -u root /home/dse/dse-azure-install/dse-directories.yml --extra-vars "host=SEED"
/usr/local/bin/ansible-playbook -u root /home/dse/dse-azure-install/dse-install.yml --extra-vars "host=SEED cluster_name=$cluster_name dc=$dc seeds=10.0.0.5"
# nodes
/usr/local/bin/ansible-playbook -u root /home/dse/dse-azure-install/os-config.yml --extra-vars "host=DSE"
/usr/local/bin/ansible-playbook -u root /home/dse/dse-azure-install/ebs-init.yml --extra-vars "host=DSE"
/usr/local/bin/ansible-playbook -u root /home/dse/dse-azure-install/dse-directories.yml --extra-vars "host=DSE"
/usr/local/bin/ansible-playbook -u root /home/dse/dse-azure-install/dse-install.yml --extra-vars "host=DSE cluster_name=$cluster_name dc=$dc seeds=10.0.0.5,10.0.0.6"
# opsc
/usr/local/bin/ansible-playbook -u root /home/dse/dse-azure-install/opscenter-install.yml --extra-vars "seeds=10.0.0.5,10.0.0.6 cluster_name=$cluster_name"

 
